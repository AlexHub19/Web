﻿using Backendv2.Entity;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Http;
using System.Collections.Generic;

namespace Backendv2.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class  ComicsController : ControllerBase
    {
        private readonly IConfiguration configuration;

        public ComicsController(IConfiguration config)
        {
            configuration = config;
        }



        [HttpGet("GetComics")]
        public IActionResult GetComics()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(configuration.GetConnectionString("DefaultConnection")))
                {
                    connection.Open();

                    string query = "SELECT * FROM Comics";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            List<ComicDTO> comics = new List<ComicDTO>();

                            while (reader.Read())
                            {
                                if (reader["id"] == DBNull.Value ||
                                    reader["nume"] == DBNull.Value ||
                                    reader["descriere"] == DBNull.Value ||
                                    reader["pret"] == DBNull.Value ||
                                    reader["imagepath"] == DBNull.Value ||
                                    reader["rating"] == DBNull.Value)
                                {
                                    return BadRequest("Probleme cu preluarea datelor din baza de date.");
                                }

                                ComicDTO comic = new ComicDTO
                                {
                                    ID = Convert.ToInt32(reader["id"]),
                                    Nume = reader["nume"].ToString(),
                                    Descriere = reader["descriere"].ToString(),
                                    Pret = reader["pret"].ToString(),
                                    ImagePath = reader["imagepath"].ToString(),
                                    Rating = Convert.ToInt32(reader["rating"])
                                };
                                comics.Add(comic);
                            }

                            return Ok(comics);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Eroare la preluarea datelor din baza de date.");
            }
        }


        [HttpPost("AddProduct")]
        public IActionResult AddProduct([FromBody] ComicDTO data)
        {
            try
            {
                string connectionString = configuration.GetConnectionString("DefaultConnection");

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string checkQuery = "SELECT COUNT(*) FROM Comics WHERE Nume = @Nume";
                    using (SqlCommand checkCommand = new SqlCommand(checkQuery, connection))
                    {
                        checkCommand.Parameters.AddWithValue("@Nume", data.Nume);
                        int count = (int)checkCommand.ExecuteScalar();

                        if (count > 0)
                        {
                            return BadRequest("Produsul cu acest nume există deja în baza de date.");
                        }
                    }

                    // If the product name does not exist, insert the new product
                    string query = @"INSERT INTO Comics (Nume, Pret, ImagePath, Descriere,Rating) 
                             VALUES (@Nume, @Pret, @ImagePath, @Descriere, @Rating)";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Nume", data.Nume);
                        command.Parameters.AddWithValue("@Pret", data.Pret);
                        command.Parameters.AddWithValue("@ImagePath", data.ImagePath);
                        command.Parameters.AddWithValue("@Descriere", data.Descriere);
                        command.Parameters.AddWithValue("@Rating", data.Rating);

                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            return Ok("Produsul a fost adaugat cu succes in baza de date.");
                        }
                        else
                        {
                            return BadRequest("Nu s-a putut adauga produsul.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Eroare la adaugarea produsului: {ex.Message}");
                return StatusCode(StatusCodes.Status500InternalServerError, "A apărut o eroare în timpul procesării cererii.");
            }
        }


        [HttpPost("DeleteComic")]
        public IActionResult DeleteComic(string denumire)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(configuration.GetConnectionString("DefaultConnection")))
                {
                    connection.Open();

                    string query = "DELETE FROM Comics WHERE Nume = @Nume";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Nume", denumire);

                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            return Ok("Produsul a fost șters cu succes.");
                        }
                        else
                        {
                            return BadRequest("Nu s-a găsit niciun produs cu acest nume.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Eroare la ștergerea produsului: {ex.Message}");
                return StatusCode(StatusCodes.Status500InternalServerError, "A apărut o eroare în timpul procesării cererii.");
            }
        }


        [HttpPost("UpdateComic")]
        public IActionResult UpdateComic([FromBody] ComicDTO data,string denumire)
        {
            try
            {
                string connectionString = configuration.GetConnectionString("DefaultConnection");

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    StringBuilder queryBuilder = new StringBuilder("UPDATE Comics SET ");
                    SqlCommand command = new SqlCommand();

                    if (!string.IsNullOrEmpty(data.Nume))
                    {
                        queryBuilder.Append("Nume = @Nume, ");
                        command.Parameters.AddWithValue("@Nume", data.Nume);
                    }

                    if (!string.IsNullOrEmpty(data.Pret))
                    {
                        queryBuilder.Append("Pret = @Pret, ");
                        command.Parameters.AddWithValue("@Pret", data.Pret);
                    }

                    if (!string.IsNullOrEmpty(data.Descriere))
                    {
                        queryBuilder.Append("Descriere = @Descriere, ");
                        command.Parameters.AddWithValue("@Descriere", data.Descriere);
                    }

                    if (!string.IsNullOrEmpty(data.ImagePath))
                    {
                        queryBuilder.Append("ImagePath = @ImagePath, ");
                        command.Parameters.AddWithValue("@ImagePath", data.ImagePath);
                    }

                    if (data.Rating > 0)
                    {
                        queryBuilder.Append("Rating = @Rating, ");
                        command.Parameters.AddWithValue("@Rating", data.Rating);
                    }

                    // Eliminăm ultima virgulă și spațiul adăugate
                    string query = queryBuilder.ToString().TrimEnd(',', ' ');

                    if (string.IsNullOrEmpty(query))
                    {
                        return BadRequest("Nu s-au furnizat date de actualizat.");
                    }

                    // Adăugăm condiția WHERE pentru a actualiza doar produsul specificat
                    query += " WHERE Nume = @NumeProdus";
                    command.Parameters.AddWithValue("@NumeProdus", denumire);


                    if (query == "UPDATE Comics SET WHERE Name = @Nume")
                        return Ok("Nu ati modificat nimic!");


                    // Adăugăm comanda și conexiunea la SqlCommand
                    command.Connection = connection;
                    command.CommandText = query;

                    // Executăm comanda SQL
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        return Ok("Produsul a fost actualizat cu succes.");
                    }
                    else
                    {
                        return BadRequest("Nu s-au putut actualiza datele produsului.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Eroare la actualizarea produsului: {ex.Message}");
                return StatusCode(StatusCodes.Status500InternalServerError, "A apărut o eroare în timpul procesării cererii.");
            }
        }


    }
}
