﻿using Backendv2.Entity;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Http;
using System.Collections.Generic;

namespace Backendv2.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ConturiController : ControllerBase
    {
        private readonly IConfiguration configuration;

        public ConturiController(IConfiguration config)
        {
            configuration = config;
        }

        [HttpPost("Save")]
        public IActionResult Save([FromBody] ContDTO data)
        {
            try
            {
                string connectionString = configuration.GetConnectionString("DefaultConnection");

                if (UsernameExists(data.Username))
                {
                    return BadRequest("Username-ul este deja folosit.");
                }

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string hashedPassword = HashPassword(data.Parola);

                    string query = @"INSERT INTO Conturi (Nume, Prenume, Telefon, Email, Username, Parola) 
                     VALUES (@Nume, @Prenume, @Telefon, @Email, @Username, @Parola)";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Nume", data.Nume);
                        command.Parameters.AddWithValue("@Prenume", data.Prenume);
                        command.Parameters.AddWithValue("@Email", data.Email);
                        command.Parameters.AddWithValue("@Telefon", data.Telefon);
                        command.Parameters.AddWithValue("@Username", data.Username);
                        command.Parameters.AddWithValue("@Parola", hashedPassword);

                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            return Ok("Datele au fost inserate cu succes.");
                        }
                        else
                        {
                            return BadRequest("Nu s-au putut insera datele.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Eroare la salvarea datelor: {ex.Message}");
                return StatusCode(StatusCodes.Status500InternalServerError, "A apărut o eroare în timpul procesării cererii.");
            }
        }

        private bool UsernameExists(string username)
        {
            string connectionString = configuration.GetConnectionString("DefaultConnection");
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = @"SELECT COUNT(*) FROM Conturi WHERE Username = @Username";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Username", username);
                    int count = (int)command.ExecuteScalar();
                    return count > 0;
                }
            }
        }



        [HttpGet("GetProfileByID")]
        public IActionResult GetProfileByID(string id)
        {
            try
            {
                string connectionString = configuration.GetConnectionString("DefaultConnection");

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = @"SELECT Username, Telefon, Email  FROM Conturi WHERE ID = @ID";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@ID", id);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                // Construiește un obiect DTO pentru datele de profil
                                var profileData = new
                                {
                                    Username = reader["Username"].ToString(),
                                    Telefon = reader["Telefon"].ToString(),
                                    Email = reader["Email"].ToString(),
                            };
                                return Ok(profileData);
                            }
                            else
                            {
                                return NotFound("Utilizatorul nu a fost găsit.");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Eroare la obținerea datelor de profil: {ex.Message}");
                return StatusCode(StatusCodes.Status500InternalServerError, "A apărut o eroare în timpul procesării cererii.");
            }
        }






        [HttpPost("logare")]
        public IActionResult Logare([FromBody] LoginDTO data)
        {
            try
            {
                string connectionString = configuration.GetConnectionString("DefaultConnection");

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string hashedPassword = HashPassword(data.Parola);

                    string query = @"SELECT Id FROM Conturi WHERE Username = @Username AND Parola = @Parola";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Username", data.Username);
                        command.Parameters.AddWithValue("@Parola", hashedPassword);

                        var userId = command.ExecuteScalar();

                        if (userId != null)
                        {
                            return Ok(userId.ToString());
                        }
                        else
                        {
                            return BadRequest("Nume de utilizator sau parolă incorecte.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Eroare la conectare: {ex.Message}");
                return StatusCode(StatusCodes.Status500InternalServerError, "A apărut o eroare în timpul procesării cererii.");
            }
        }



        [HttpPost("UpdateProfile")]
        public IActionResult UpdateProfile([FromBody] ContDTO data)
        {
            try
            {
                string connectionString = configuration.GetConnectionString("DefaultConnection");

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    StringBuilder queryBuilder = new StringBuilder("UPDATE Conturi SET ");
                    SqlCommand command = new SqlCommand();
                    int usedusername = 0;
                    if (!string.IsNullOrEmpty(data.Username))
                    {
                        if (UsernameExists(data.Username))
                        {
                            usedusername = 1;
                        }
                        else
                        {
                            queryBuilder.Append("Username = @Username, ");
                            command.Parameters.AddWithValue("@Username", data.Username);

                        }
                    }

                    if (!string.IsNullOrEmpty(data.Telefon))
                    {
                        queryBuilder.Append("Telefon = @Telefon, ");
                        command.Parameters.AddWithValue("@Telefon", data.Telefon);
                    }

                    if (!string.IsNullOrEmpty(data.Email))
                    {
                        queryBuilder.Append("Email = @Email, ");
                        command.Parameters.AddWithValue("@Email", data.Email);
                    }

                    

                    string hashedCurrentPassword = HashPassword(data.Parola);
                    if (!string.IsNullOrEmpty(data.Parola))
                    {
                        // Selectăm parola din baza de date pentru utilizatorul curent
                        string selectPasswordQuery = @"SELECT Parola FROM Conturi WHERE ID = @UserID";
                        using (SqlCommand selectPasswordCommand = new SqlCommand(selectPasswordQuery, connection))
                        {
                            selectPasswordCommand.Parameters.AddWithValue("@UserID", data.ID);
                            string storedPassword = (string)selectPasswordCommand.ExecuteScalar();

                            // Verificăm dacă parola introdusă corespunde cu cea din baza de date
                            if (hashedCurrentPassword != storedPassword)
                            {
                                return BadRequest("Parola curentă introdusă nu este corectă.");
                            }
                            else
                            {
                                queryBuilder.Append("Parola = @Parola, ");
                                command.Parameters.AddWithValue("@Parola", HashPassword(data.NouaParola));
                            }
                        }
                    }


                    // Eliminăm ultima virgulă și spațiul adăugate în excepția cazului în care nu actualizăm niciun câmp
                    string query = queryBuilder.ToString().TrimEnd(',', ' ');

                    if (string.IsNullOrEmpty(query))
                    {
                        return BadRequest("Nu s-au furnizat date de actualizat.");
                    }

                    // Adăugăm condiția WHERE pentru a actualiza doar pentru utilizatorul specificat
                    query += " WHERE ID = @UserID";
                    command.Parameters.AddWithValue("@UserID", data.ID);

                    // Adăugăm comanda și conexiunea la SqlCommand
                    command.Connection = connection;
                    command.CommandText = query;

                    if (usedusername == 1)
                        return BadRequest("Username deja existent");
                   
                    if (query == "UPDATE Conturi SET WHERE ID = @UserID")
                        return Ok("Nu ati modificat nimic!");
                    // Executăm comanda SQL
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        
                            return Ok("Profilul utilizatorului a fost actualizat cu succes.");
                    }
                    else
                    {
                        return BadRequest("Nu s-au putut actualiza datele profilului.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Eroare la actualizarea profilului: {ex.Message}");
                return StatusCode(StatusCodes.Status500InternalServerError, "A apărut o eroare în timpul procesării cererii.");
            }
        }




        [HttpGet("GetUsers")]
        public IActionResult GetUsers()
        {
            try
            {
                string connectionString = configuration.GetConnectionString("DefaultConnection");

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = @"SELECT  Nume, Prenume, Telefon, Email, Username FROM Conturi";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            var users = new List<object>();

                            while (reader.Read())
                            {
                                var user = new
                                {
                                    Nume = reader["Nume"],
                                    Prenume = reader["Prenume"],
                                    Telefon = reader["Telefon"],
                                    Email = reader["Email"],
                                    Username = reader["Username"]
                                };

                                users.Add(user);
                            }

                            return Ok(users);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Eroare la obținerea utilizatorilor: {ex.Message}");
                return StatusCode(StatusCodes.Status500InternalServerError, "A apărut o eroare în timpul procesării cererii.");
            }
        }



        [HttpPost("DeleteUser")]
        public IActionResult DeleteUser(string username)
        {
            try
            {
                string connectionString = configuration.GetConnectionString("DefaultConnection");

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = @"DELETE FROM Conturi WHERE Username = @Username";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Username", username);

                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            return Ok("Utilizatorul a fost șters cu succes.");
                        }
                        else
                        {
                            return NotFound("Utilizatorul nu a fost găsit.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Eroare la ștergerea utilizatorului: {ex.Message}");
                return StatusCode(StatusCodes.Status500InternalServerError, "A apărut o eroare în timpul procesării cererii.");
            }
        }






        [HttpPost("UpdateContactInfo")]
        public IActionResult UpdateContactInfo([FromBody] ContDTO data, string actualUsername)
        {
            try
            {
                string connectionString = configuration.GetConnectionString("DefaultConnection");

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    StringBuilder queryBuilder = new StringBuilder("UPDATE Conturi SET ");
                    SqlCommand command = new SqlCommand();
                    int usedUsername = 0;

                    if (!string.IsNullOrEmpty(data.Username) && data.Username != actualUsername)
                    {
                        if (UsernameExists(data.Username))
                        {
                            usedUsername = 1;
                        }
                        else
                        {
                            queryBuilder.Append("Username = @NewUsername, ");
                            command.Parameters.AddWithValue("@NewUsername", data.Username);
                        }
                    }

                    if (!string.IsNullOrEmpty(data.Telefon))
                    {
                        queryBuilder.Append("Telefon = @Telefon, ");
                        command.Parameters.AddWithValue("@Telefon", data.Telefon);
                    }

                    if (!string.IsNullOrEmpty(data.Email))
                    {
                        queryBuilder.Append("Email = @Email, ");
                        command.Parameters.AddWithValue("@Email", data.Email);
                    }

                    // Eliminăm ultima virgulă și spațiul adăugate
                    string query = queryBuilder.ToString().TrimEnd(',', ' ');

                    if (string.IsNullOrEmpty(query))
                    {
                        return BadRequest("Nu s-au furnizat date de actualizat.");
                    }

                    // Adăugăm condiția WHERE pentru a actualiza doar pentru utilizatorul specificat
                    query += " WHERE Username = @ActualUsername";
                    command.Parameters.AddWithValue("@ActualUsername", actualUsername);

                    // Adăugăm comanda și conexiunea la SqlCommand
                    command.Connection = connection;
                    command.CommandText = query;

                    if (usedUsername == 1)
                        return BadRequest("Username deja existent");

                    if (query == "UPDATE Conturi SET WHERE Username = @ActualUsername")
                        return Ok("Nu ati modificat nimic!");

                    // Executăm comanda SQL
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        return Ok("Informațiile de contact ale utilizatorului au fost actualizate cu succes.");
                    }
                    else
                    {
                        return BadRequest("Nu s-au putut actualiza informațiile de contact.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Eroare la actualizarea informațiilor de contact: {ex.Message}");
                return StatusCode(StatusCodes.Status500InternalServerError, "A apărut o eroare în timpul procesării cererii.");
            }
        }






        // Funcție pentru criptarea parolei
        private string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                foreach (byte b in hashedBytes)
                {
                    builder.Append(b.ToString("x2"));
                }
                return builder.ToString();
            }
        }
    }
}
