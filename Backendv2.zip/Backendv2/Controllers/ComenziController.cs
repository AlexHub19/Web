﻿using Backendv2.Entity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Http;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;

namespace Backendv2.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ComenziController : ControllerBase
    {
        private readonly IConfiguration configuration;

        public ComenziController(IConfiguration config)
        {
            configuration = config;
        }

        [HttpPost("PlaseazaComanda")]
        public IActionResult PlaseazaComanda([FromBody] ComandaDTO comanda)
        {
            try
            {
                // Verificare ID utilizator valid
                if (comanda.IDUtilizator < 0)
                {
                    return BadRequest("ID-ul utilizatorului trebuie să fie un număr mai mare sau egal cu 0.");
                }

                // Connectare la baza de date folosind configurarea
                string connectionString = configuration.GetConnectionString("DefaultConnection");

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Definirea comenzii SQL pentru inserarea datelor
                    string insertQuery = @"INSERT INTO Comenzi (IDUtilizator, Cost, NrProduse, DetaliiProduse) 
                                           VALUES (@IDUtilizator, @Cost, @NrProduse, @DetaliiProduse)";

                    // Creare obiect SqlCommand
                    using (SqlCommand command = new SqlCommand(insertQuery, connection))
                    {
                        // Adăugare parametrii pentru inserare
                        command.Parameters.AddWithValue("@IDUtilizator", comanda.IDUtilizator);
                        command.Parameters.AddWithValue("@Cost", comanda.Cost);
                        command.Parameters.AddWithValue("@NrProduse", comanda.NumarProduse);
                        command.Parameters.AddWithValue("@DetaliiProduse", comanda.DetaliiProduse);

                        // Executarea comenzii SQL
                        command.ExecuteNonQuery();
                    }
                }

                return Ok("Comanda a fost plasată cu succes!");
            }
            catch (Exception ex)
            {
                // Tratarea erorilor
                return StatusCode(StatusCodes.Status500InternalServerError, "A apărut o eroare în procesul de plasare a comenzii: " + ex.Message);
            }
        }



     [HttpGet("ComenziUtilizator")]
    public IActionResult GetComenziUtilizator(int idUtilizator)
    {
        try
        {
            // Connectare la baza de date folosind configurarea
            string connectionString = configuration.GetConnectionString("DefaultConnection");

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Definirea comenzii SQL pentru a obține informațiile despre comenzi
                string selectQuery = @"SELECT IDComanda, Cost, DataComanda, NrProduse, DetaliiProduse 
                                   FROM Comenzi 
                                   WHERE IDUtilizator = @IDUtilizator";

                // Creare obiect SqlCommand
                using (SqlCommand command = new SqlCommand(selectQuery, connection))
                {
                    // Adăugare parametrul pentru ID-ul utilizatorului
                    command.Parameters.AddWithValue("@IDUtilizator", idUtilizator);

                    // Executarea comenzii SQL și citirea rezultatelor
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        List<ComandaDTO> comenzi = new List<ComandaDTO>();

                        while (reader.Read())
                        {
                            ComandaDTO comanda = new ComandaDTO
                            {
                                IDComanda = reader.GetInt32(0),
                                Cost = reader.GetInt32(1),
                                DataComanda = reader.GetDateTime("DataComanda").ToString("dd/MM/yyyy"),
                                NumarProduse = reader.GetInt32(3),
                                DetaliiProduse = reader.GetString(4)
                            };

                            comenzi.Add(comanda);
                        }

                        // Returnarea datelor sub formă de JSON
                        return Ok(comenzi);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            // Tratarea erorilor
            return StatusCode(StatusCodes.Status500InternalServerError, "A apărut o eroare în procesul de obținere a informațiilor despre comenzi: " + ex.Message);
        }
    }

        [HttpGet("GetPopular")]
        public IActionResult GetPopular()
        {
            try
            {
                // Connectare la baza de date folosind configurarea
                string connectionString = configuration.GetConnectionString("DefaultConnection");

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Definirea comenzii SQL pentru a obține informațiile despre comenzi
                    string selectQuery = @"SELECT DetaliiProduse 
                                           FROM Comenzi";

                    using (SqlCommand command = new SqlCommand(selectQuery, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            List<string> detaliiProduseList = new List<string>();

                            while (reader.Read())
                            {
                                string detaliiProduse = reader.GetString(0);
                                detaliiProduseList.Add(detaliiProduse);
                            }

                            var produse = ParseazaDetaliiProduse(detaliiProduseList);
                            var produseGrupate = GrupeazaProduse(produse);

                            if (produseGrupate.Any())
                            {
                                var produsPopular = produseGrupate.OrderByDescending(p => p.nrProdus).First();
                                return Ok(produsPopular.denumireProdus);
                            }
                            else
                            {
                                return NotFound("Nu au fost găsite produse.");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Tratarea erorilor
                return StatusCode(StatusCodes.Status500InternalServerError, "A apărut o eroare în procesul de obținere a informațiilor despre comenzi: " + ex.Message);
            }
        }

        private List<(string denumireProdus, int nrProdus)> ParseazaDetaliiProduse(List<string> detaliiProduseList)
        {
            List<(string denumireProdus, int nrProdus)> produse = new List<(string denumireProdus, int nrProdus)>();

            foreach (var detalii in detaliiProduseList)
            {
                var produseIndividuale = detalii.Split('|');
                foreach (var produs in produseIndividuale)
                {
                    var parts = produs.Split('*');
                    if (parts.Length == 2 && int.TryParse(parts[0], out int nrProdus))
                    {
                        produse.Add((parts[1], nrProdus));
                    }
                }
            }

            return produse;
        }

        private List<(string denumireProdus, int nrProdus)> GrupeazaProduse(List<(string denumireProdus, int nrProdus)> produse)
        {
            var produseGrupate = produse
                .GroupBy(p => p.denumireProdus)
                .Select(g => (denumireProdus: g.Key, nrProdus: g.Sum(p => p.nrProdus)))
                .ToList();

            return produseGrupate;
        }




    }
}
