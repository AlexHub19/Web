﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Backendv2.Entity
{
    public class LoginDTO
    {
        public string Username { get; set; }
        public string Parola { get; set; }
    }
}
