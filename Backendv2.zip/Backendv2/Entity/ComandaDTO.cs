﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Backendv2.Entity
{
    public class ComandaDTO
    {
        public int IDComanda { get; set; }

        public int IDUtilizator { get; set; }

        public int Cost { get; set; }

        public string DataComanda { get; set; }
        public int NumarProduse { get; set; }

        public string DetaliiProduse { get; set; }
    }
}
