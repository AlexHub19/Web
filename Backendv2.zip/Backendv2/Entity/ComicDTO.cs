﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Backendv2.Entity
{
    public class ComicDTO
    {
        public int ID { get; set; }
        public string Nume { get; set; }
        public string Descriere { get;  set; }
        public string Pret { get; set; }
        public string ImagePath { get; set; }
        public int Rating { get; set; }

    }
}
