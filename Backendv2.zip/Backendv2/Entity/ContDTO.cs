﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Backendv2.Entity
{
    public class ContDTO
    {
        public int ID { get; set; }

        public string Nume { get; set; }

        public string Prenume { get; set; }

        public string Username { get; set; }

        public string Email { get; set; }

        public string Parola { get; set; }

        public string Telefon { get; set; }

        public string NouaParola { get; set; }


    }
}
